/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.web.controller.impl;

import com.spring.web.common.ICommonController;

/**
 *
 * @author Asus
 */
public interface IAddServiceController extends ICommonController {
    
}
