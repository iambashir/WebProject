package com.java.servlet;

public interface DBIntializer {
    String DRIVER="com.mysql.jdbc.Driver";
    String CON_STRING="jdbc:mysql://localhost:3306/servlet";
    String USERNAME="root";
    String PASSWORD="root";
}
