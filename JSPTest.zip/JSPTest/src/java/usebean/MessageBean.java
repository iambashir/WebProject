
package usebean;

/**
 *
 * @author User
 */
public class MessageBean {
    private String message="No message set yet";

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }   
    
    
}
