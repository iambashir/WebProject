package com.apress.projsp;

public class SourceBean {
  String string;

  public String getString() {
    return string;
  }

  public void setString(String s) {
    string = s;
  }
}