export class Employee {
catid: string;
catname: string;
description: string;
}